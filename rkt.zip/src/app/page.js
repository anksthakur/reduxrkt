
import AddUser from "./components/AddUser";
import DisplayUsers from "./components/DisplayUser";


export default function Home() {
  return (
    <main >
    <AddUser/>
    <DisplayUsers/>
    </main>
  );
}
